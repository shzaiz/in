1.in/out ~ 20.in/out 数据文件

filldata.exe/cpp 把输出填写到out文件
gen.cpp/exe 数据生成器
std.cpp 标程