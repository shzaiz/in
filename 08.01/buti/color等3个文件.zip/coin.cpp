#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("coin.in","r",stdin);
	freopen("coin.out","w",stdout)
	int a,b;
	cin>>a>>b;
	cout<<(b/a)<<endl;
} 
