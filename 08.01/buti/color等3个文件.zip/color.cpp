#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("color.in","r",stdin);
	freopen("color.out","w",stdout)
	int a,b;
	cin>>a>>b;
	cout<<0<<endl;
} 
