#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

const int xGo[4]={-1,0,1,0};
const int yGo[4]={0,-1,0,1};

int n,m,map[220][220][2];
int x,y,fOri,wOri,maxCilp,totCilp,cilp[32],bigBullet,smallBullet,k,endIf,totTarget;

void IN_Map_Robot();
void OutPut(int);
int Para(char str[]);

void FortCom(char str[]);
void WheelCom(char str[]);
void EndCom(char str[]);

int main()
{
    freopen("robo.in","r",stdin);
    freopen("robo.out","w",stdout);
    int t;
    scanf("%d",&t);
    while(t--)
    {
        IN_Map_Robot();
        while(k--)
        {
            char str[10];
            cin.getline(str,10);
            if(endIf) continue;
            if(str[0]=='F') FortCom(str);
            if(str[0]=='W') WheelCom(str);
            if(str[0]=='E') EndCom(str);
        }
        if(!endIf) OutPut(0);
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}

void IN_Map_Robot()
{
    memset(map,0,sizeof(map));
    totCilp=0,fOri=0,wOri=0,endIf=0,totTarget=0;

    scanf("%d%d",&n,&m);
    for(int i=0;i<n;++i)
        for(int j=0;j<m;++j)
            scanf("%d ",&map[i][j][0]);
    scanf("%d %d %d %d %d %d\n",&x,&y,&maxCilp,&bigBullet,&smallBullet,&k);
}

void FortCom(char str[])
{
    if(str[1]=='T')
    {
        int par=Para(str+3);
        if(par==0) fOri=(fOri+1)%4;
        else if(par==1) fOri=(fOri+3)%4;
        else { OutPut(0); return ; }
    }
    if(str[1]=='F')
    {
        int par=Para(str+3);
        if((par==0&&smallBullet==0)||(par==1&&bigBullet==0)) return;
        if(par==0&&totCilp<maxCilp) cilp[++totCilp]=par,smallBullet--;
        else if(par==1&&totCilp<maxCilp) cilp[++totCilp]=par,bigBullet--;
        else { OutPut(0); return ; }
    }
    if(str[1]=='E')
    {
        if(totCilp==0) return ;
        int nx,ny;
        for(int i=1;;++i)
        {
            nx=x+xGo[fOri]*i,ny=y+yGo[fOri]*i;
            if(nx<0||nx>=n||ny<0||ny>=m) break;
            if(map[nx][ny][0]==1||map[nx][ny][0]==2) break;
        }
        totCilp--;
        if(nx<0||nx>=n||ny<0||ny>=m) return ;
        if(map[nx][ny][0]==1) return ;
        if(cilp[totCilp+1]||map[nx][ny][1]) { map[nx][ny][0]=0; totTarget++; }
        else map[nx][ny][1]=1;
    }
}

void WheelCom(char str[])
{
    if(str[1]=='T')
    {
        int par=Para(str+3);
        if(par==0) wOri=(wOri+1)%4;
        else if(par==1) wOri=(wOri+3)%4;
        else { OutPut(0); return ; }
    }
    else
    {
        int par=Para(str+3);
        int nx=x+xGo[wOri]*par,ny=y+yGo[wOri]*par;
        if(nx<0||nx>=n||ny<0||ny>=m) { OutPut(0); return ; }
        else
        {
            for(int i=1;i<=par;++i)
            {
                nx=x+xGo[wOri]*i,ny=y+yGo[wOri]*i;
                if(map[nx][ny][0]) { OutPut(0); return ; }
            }
        }
        x=nx,y=ny;
    }
}

void EndCom(char str[])
{
    OutPut(1);
}

void OutPut(int type)
{
    endIf=1;
    if(type) printf("Complete\n");
    else printf("ERROR\n");
    printf("%d %d\n",x,y);
    printf("%d\n",totTarget);
    printf("%d %d %d %d\n",fOri,wOri,bigBullet,smallBullet);
}

int Para(char str[])
{
    int i,re=0;
    for(i=0;;++i)
    {
        if(str[i]=='.') return 114514;
        if(str[i]=='\0') break;
    }
    i=0;
    do
    {
        re=re*10+(str[i]-'0');
        i++;
    }while(str[i]!='\0');
    return re;
}
