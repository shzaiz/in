#include <bits/stdc++.h>

using namespace std;

const int N=505,M=505,K=15;
const int dx[4]={0,0,1,-1};
const int dy[4]={1,-1,0,0};
const char* st[4]={"R","L","D","U"};

int Path[(N+M)<<1],n,m,S;
int mp[N][M];

void Read_Map() {
	scanf("%d%d%d",&n,&m,&S);
	for (int i=0;i<n;++i) 
		for (int j=0;j<m;++j) scanf("%d",&mp[i][j]);//mp=0Ϊ���У�����Ϊ�ϰ� 
}

queue<pair<int,int> >Q;
int Path_[K+1][K+1][(N+M)<<1],dist[K+1][K+1],szt[K+1][K+1];
int dis[K][1<<K],sum[K][1<<K];
pair<int,int> pre[K][1<<K];


void Put_Path(int *Path,int &len,int begin,int end) {
	for (int i=0;i<dist[begin][end];++i)
		Path[len++]=Path_[begin][end][i];
}

bool CoordValid(int x,int y) {
	return x>=0 && x<n && y>=0 && y<m;
}

bool CoordValid(int x,int y,int size) {
	for (int i=-size;i<=size;++i)
		for (int j=-size;j<=size;++j)
			if (!CoordValid(x+i,y+j) || mp[x+i][y+j]==1) return 0;
	return 1;
}

int Size(int x,int y) {
	for (int i=S;i>=0;--i) if (CoordValid(x,y,i)) return i; 
	return -1;
}

int pree[N][M],diss[N][M],sz[N][M];
void FindPath(int *ax,int *ay,int count) {
	for (int i=0;i<count;++i) {
 		Q.push(make_pair(ax[i],ay[i]));
		memset(pree,0,sizeof(pree));
		memset(diss,0x7f,sizeof(diss));
		memset(sz,0,sizeof(sz));
		diss[ax[i]][ay[i]]=0;
		while (!Q.empty()) {
			pair<int,int> u=Q.front(); Q.pop();
			for (int i=0;i<4;++i) {
				int tx=u.first+dx[i],ty=u.second+dy[i],s=Size(tx,ty);
				if (s!=-1 && (diss[tx][ty]>diss[u.first][u.second]+1 || (diss[tx][ty]==diss[u.first][u.second]+1 && sz[u.first][u.second]+s>sz[tx][ty]))) {
					diss[tx][ty]=diss[u.first][u.second]+1;
					pree[tx][ty]=i;
					sz[tx][ty]=sz[u.first][u.second]+s;
					Q.push(make_pair(tx,ty));
				}
			}
		}
		for (int j=0;j<count;++j) {
			dist[i][j]=diss[ax[j]][ay[j]];
			szt[i][j]=sz[ax[j]][ay[j]];
//			int len=0,nowx=ax[j],nowy=ay[j];
//			while (nowx!=ax[i] || nowy!=ay[i]) {
//				Path_[i][j][len++]=pree[nowx][nowy];
//				int px=nowx-dx[pree[nowx][nowy]],py=nowy-dy[pree[nowx][nowy]];
//				nowx=px; nowy=py;
//			}
//			reverse(Path_[i][j],Path_[i][j]+len);
		}
	}
}

void Planning(int now_x,int now_y,int *aim_x,int *aim_y,int count_aim,int *Path,int &len) {
	aim_x[count_aim]=now_x; aim_y[count_aim]=now_y;
	FindPath(aim_x,aim_y,count_aim+1);
	int Mx=1<<count_aim;
	for (int i=0;i<=count_aim;++i)
		for (int j=0;j<Mx;++j)
			pre[i][j]=make_pair(-1,-1),dis[i][j]=1<<30;
	for (int i=0;i<count_aim;++i) dis[i][(Mx-1)^(1<<i)]=0,sum[i][(Mx-1)^(1<<i)]=0;
	for (int i=0;i<count_aim;++i)
		for (int j=Mx-1;j>=0;--j)
			for (int k=0;k<count_aim;++k) if (i!=k && !((j>>k)&1) && (dis[i][j]>dis[k][j^(1<<i)]+dist[i][k] || ( dis[i][j]==dis[k][j^(1<<i)]+dist[i][k] && sum[i][j]<sum[k][j^(1<<i)]+szt[i][k] ) )) {
				dis[i][j]=dis[k][j^(1<<i)]+dist[i][k];
				sum[i][j]=sum[k][j^(1<<i)]+szt[i][k];
				pre[i][j]=make_pair(k,j^(1<<i)); 
			} 

	int mn=0,v=0; len=0;
	for (int i=1;i<count_aim;++i) if (dis[i][v]+dist[count_aim][i]<dis[mn][v]+dist[count_aim][mn] || (dis[i][v]+dist[count_aim][i]==dis[mn][v]+dist[count_aim][mn] && sum[i][v]+szt[count_aim][i]>sum[mn][v]+szt[count_aim][mn])) mn=i;
	printf("%d %d\n",dis[mn][v]+dist[count_aim][mn],sum[mn][v]+Size(now_x,now_y)+szt[count_aim][mn]);
/*
	for (int i=1;i<count_aim;++i) if (dis[i][v]+dist[count_aim][i]<dis[mn][v]+dist[count_aim][mn]) mn=i;
	Put_Path(Path,len,count_aim,mn);
	while (pre[mn][v].first!=-1) {
		pair<int,int> u=pre[mn][v];
		Put_Path(Path,len,mn,u.first);
		mn=u.first; v=u.second;
	}
*/ 
}

int main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	Read_Map();
	int now_x,now_y,aim_x[K],aim_y[K],count_aim;
	scanf("%d%d%d",&now_x,&now_y,&count_aim);
	for (int i=0;i<count_aim;++i) scanf("%d%d",&aim_x[i],&aim_y[i]);
	int len=0;
	Planning(now_x,now_y,aim_x,aim_y,count_aim,Path,len);
//	for (int i=0;i<len;++i) 
//		printf("%s",st[Path[i]]);
	putchar('\n');
	fclose(stdin);
	fclose(stdout);
	return 0; 
} 

/*
input: 
4 6 3
1 1 1 0 0 0 
0 0 0 0 0 0 
0 0 0 0 0 0 
0 0 0 0 0 0 
0 4 1
3 0 

output:
7 5
*/
