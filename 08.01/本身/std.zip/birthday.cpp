# include <iostream>
# include <cstdio>
# include <cstring>
# include <cstdlib>
using namespace std;
const int V = 1e3 + 10;
const int N = 1e5 + 12;
int read()
{
    int ans = 0,f = 1;
    char i = getchar();
    while(i < '0' || i > '9'){if(i == '-')f = -1;i = getchar();}
    while(i >= '0' && i <= '9'){ans = ans * 10 + i - '0';i = getchar();}
    return ans * f;
}
int n,m,v,mid,ol,x,y,d;
int data[V][22],a[N],stack[N],cnt;
int sum[N << 2],lazy[N << 2];
bool flag[N];
void down(int rt){
    lazy[rt << 1] += lazy[rt];
    lazy[rt << 1 | 1] += lazy[rt];
    lazy[rt] = 0;
}
void push(int &ans,int &r){
    int j = 20;
    while(j >= 0){
        if(r >= (1 << j)){
           ans = data[ans][j];
           r -= (1 << j);
           if(r == 0)return;
        }
        j--;
    }
}
void updata(int L,int R,int l,int r,int rt){
    if(L <= l && r <= R){
        lazy[rt]++;
        return;
    }
    if(lazy[rt])down(rt);
    int mid = (l + r) >> 1;
    if(L <= mid)updata(L,R,l,mid,rt << 1);
    if(R >  mid)updata(L,R,mid + 1,r,rt << 1 | 1);
    return;
}
void Query(int L,int l,int r,int rt){
    if(l == r){
        push(a[L],lazy[rt]);
        return;
    }
    if(lazy[rt])down(rt);
    int mid = (l + r) >> 1;
    if(L <= mid)Query(L,l,mid,rt << 1);
    else Query(L,mid + 1,r,rt << 1 | 1);
    return;
}
void init(){
    for(int i = 0;i < v;i++){
        data[i][0] = (i * i % v) * i % v;
    }
    for(int j = 1;j <= 20;j++){
        for(int i = 0;i < v;i++){
           data[i][j] = data[data[i][j - 1]][j - 1];
        }    
    }
}
void dfsl(int u,int dis,bool k){
    if(ol)return;
    if(u == mid + 1){
        if(k){
            if(!dis){
                ol = true;
            }else if(dis >= 0 && !flag[dis]){flag[dis] = true;stack[++cnt] = dis;}
        }
        return;
    }
    dfsl(u + 1,dis,k);
    dfsl(u + 1,dis + a[u] + 1,true);
    dfsl(u + 1,dis - a[u] - 1,true);
    return;
}
void dfsr(int u,int dis,bool k){
    if(ol)return;
    if(u == y + 1){
        if(k){
            if(!dis){
                ol = true;
            }else if(dis >= 0 && flag[dis]){
                ol = true;
            }
        }
        return;
    }
    dfsr(u + 1,dis,k);
    dfsr(u + 1,dis + a[u] + 1,true);
    dfsr(u + 1,dis - a[u] - 1,true);
    return;
}
int main(){
     freopen("birthday.in","r",stdin);
     freopen("birthday.out","w",stdout);
  n = read(),m = read(),v = read();
  for(int i = 1;i <= n;i++)a[i] = read();
  init();
  for(int i = 1;i <= m;i++){
      d = read(),x = read(),y = read();
      if(d == 2){
          updata(x,y,1,n,1);
      }else {
          if(y - x >= 13){
              puts("Yes");
          }else {
            for(int j = x;j <= y;j++){
                Query(j,1,n,1);
            }
            mid = (x + y) >> 1;
            ol = false;cnt = 0;
            dfsl(x,0,false);
            dfsr(mid + 1,0,false);
            for(int i = 1;i <= cnt;i++){
                flag[stack[i]] = false;
            }
            if(ol)puts("Yes");else puts("No");
         }
      }
  }
  fclose(stdin);
  fclose(stdout);
  return 0;
}
